package PageObjects;

import CommonUtilities.SeleniumUtilities;
import CommonUtilities.StaticInjections;
import CommonUtilities.Utilities;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WebsitePageFactory
{
    WebDriver driver=Utilities.driver;
    SeleniumUtilities SU=new SeleniumUtilities();
    @FindBy(xpath = "//h1[text()='Welcome to Gurukula!']")
    WebElement welcomeLabel;
    @FindBy(xpath = "//a[text()='login']")
    WebElement loginButton;
    @FindBy(xpath = "//input[@id='username']")
    WebElement usernameTextBox;
    @FindBy(xpath = "//input[@id='password']")
    WebElement passwordTextBox;
    @FindBy(xpath = "//button[@type='submit']")
    WebElement authenticateButton;
    @FindBy(xpath = "//div[contains(text(),'You are logged in as user')]")
    WebElement loggedInText;
    @FindBy(xpath = "//span[text()='Account']")
    WebElement accountButton;
    @FindBy(xpath = "//span[text()='Log out']")
    WebElement logoutButton;
    @FindBy(xpath = "//strong[text()='Authentication failed!']")
    WebElement authenticationError;
    @FindBy(xpath = "//span[text()='Settings']")
    WebElement settingsButton;
    @FindBy(xpath = "//input[@name='firstName']")
    WebElement firstNameText;
    @FindBy(xpath = "//input[@name='firstName']")
    WebElement lastNameText;
    @FindBy(xpath = "//input[@name='firstName']")
    WebElement emailText;
    @FindBy(xpath = "//strong[text()='Settings saved!']")
    WebElement saveAlert;
    @FindBy(xpath = "//strong[text()='Settings saved!']")
    WebElement settingdSave;
    @FindBy(xpath = "//span[text()='Entities']")
    WebElement entitiesButton;
    @FindBy(xpath = "//span[text()='Branch']")
    WebElement branchButton;
    @FindBy(xpath = "//span[text()='Staff']")
    WebElement staffButton;
    @FindBy(xpath = "//span[text()='Create a new Branch']")
    WebElement newBranchButton;
    @FindBy(xpath = "//span[text()='Create a new Staff']")
    WebElement newStaffButton;
    @FindBy(xpath = "//input[@name='name']")
    WebElement branchNameText;
    @FindBy(xpath = "//select[@name='related_branch']")
    WebElement branchSelectDropdown;
    @FindBy(xpath = "//input[@name='code']")
    WebElement codeNameText;
    @FindBy(xpath = "//span[text()='Save']")
    WebElement saveBranch;
    @FindBy(xpath = "(//span[text()='View']/..)[last()]")
    WebElement viewBranch;
    @FindBy(xpath = "//span[text()='Back']")
    WebElement backButton;
    @FindBy(xpath = "(//span[text()='Edit'])[last()]")
    WebElement editBranch;
    @FindBy(xpath = "((//span[text()='Delete'])[2])[last()]")
    WebElement deleteBranch;
    @FindBy(xpath = "((//span[text()='Delete'])[1])[last()]")
    WebElement deleteBranchPopup;
    @FindBy(xpath = "(//tr[@ng-repeat='branch in branches']//a)[last()]")
    WebElement idOfBranch;
    @FindBy(xpath = "(//tr[@ng-repeat='staff in staffs']//a)[last()]")
    WebElement idOfStaff;
    @FindBy(xpath = "//input[@id='searchQuery']")
    WebElement searchQueryBox;
    @FindBy(xpath = "//a[text()='Register a new account']")
    WebElement registerNewUserLink;
    @FindBy(xpath = "//h1[text()='Registration']")
    WebElement registrationLabel;
    @FindBy(xpath = "//input[@name='login']")
    WebElement loginTextBox;
    @FindBy(xpath = "//input[@name='email']")
    WebElement emailTextBox;
    @FindBy(xpath = "//input[@name='password']")
    WebElement passwordTextBoxRegistration;
    @FindBy(xpath = "//input[@name='confirmPassword']")
    WebElement confirmPasswordTextBoxRegistration;
    @FindBy(xpath = "//strong[text()='Registration saved!']")
    WebElement regSaved;
    @FindBy(xpath = "// strong[text()='Registration failed!']")
    WebElement regFailed;


    public WebsitePageFactory(WebDriver driver) {
        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }

    public void verifyWelcomePage()
    {
        if(loginButton.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is on the welcome page of website");
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"Welcome page of website is failed to load");
        }
    }

    public void clickLoginButton()
    {
        SU.JSClick(loginButton);
    }

    public void enterUserName(String userName)
    {
        SU.enterText(usernameTextBox,userName);
    }
    public void enterPassword(String password)
    {
       SU.enterText(passwordTextBox,password);
    }

    public void verifyAuthentication()
    {
        if(authenticationError.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"Authentication Error message is displayed for Invalid Credentials");
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"Authentication Error message does not displayed for Invalid Credentialse");
        }
    }

    public void clickSignInButton() throws InterruptedException {
        SU.JSClick(authenticateButton);
        Thread.sleep(2000);
    }

    public void clickAccountButton() throws InterruptedException
    {
        SU.JSClick(accountButton);
        Thread.sleep(2000);
    }

    public void clickLogoutButton() throws InterruptedException {
        SU.JSClick(logoutButton);
        Thread.sleep(2000);
        if(loginButton.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is logged out successfully and navigated back to Welcome page");
        }
        else{
            StaticInjections.extentTest.log(LogStatus.FAIL,"User is failed to logged out");
        }
    }

    public void verifyHomePage()
    {
        if(loggedInText.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is logged in successfully and navigated to Home page");
        }
        else{
            StaticInjections.extentTest.log(LogStatus.FAIL,"User is failed to logged in");
        }
    }

    public void clickOnSettings() throws InterruptedException {
        SU.JSClick(settingsButton);
        Thread.sleep(2000);
        if(firstNameText.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is navigated to User settings page");
        }
        else{
            StaticInjections.extentTest.log(LogStatus.FAIL,"User is failed to navigated to User settings page");
        }
    }

    String firstName="";
    String lastName="";
    String emailId="";
    public void updateDetails()
    {
        firstName=firstNameText.getAttribute("value");
        lastName=lastNameText.getAttribute("value");;
        emailId=emailText.getAttribute("value");;
        if(firstName.substring(0,(firstName.length()/2)-1).equalsIgnoreCase(firstName.substring((firstName.length()/2)+1,firstName.length()-1)))
        {
            firstName=firstName.substring(0,(firstName.length()/2)-1);
            lastName=lastName.substring(0,(lastName.length()/2)-1);
            emailId=emailId.substring(1,emailId.length()-1);
        }
        else
        {
            firstName=firstName+firstName;
            lastName=lastName+lastName;
            emailId=emailId.substring(0,1)+emailId;
        }
        SU.enterText(firstNameText,firstName);
        SU.enterText(lastNameText,lastName);
        SU.enterText(emailText,emailId);
        SU.JSClick(authenticateButton);
    }

    public void verifySettingsUpdated()
    {
        if (settingdSave.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User details are updated successfully");
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"User details are failed to update");
        }
    }

    public void clickOnEntities()
    {
        SU.JSClick(entitiesButton);
    }

    public void clickOnBranch()
    {
        SU.JSClick(branchButton);
    }

    public void clickOnStaff()
    {
        SU.JSClick(staffButton);
    }

    public void verifyCreateBranchButton(String entity)
    {
        if (newBranchButton.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User successfully displayed an option to Create a new"+entity);
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"User failed to displayed an option to Create a new"+entity);
        }
    }

    public void verifyCreateStaffButton()
    {
        if (newStaffButton.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User successfully displayed an option to Create a new staff");
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"User failed to displayed an option to Create a new staff");
        }
    }

    public String createNewBranch(String branchName, String code) throws InterruptedException {
        SU.JSClick(newBranchButton);
        SU.JSClick(branchNameText);
        Thread.sleep(2000);
        SU.enterText(branchNameText,branchName);
        SU.JSClick(codeNameText);
        SU.enterText(codeNameText,code);
        SU.JSClick(saveBranch);
        Thread.sleep(3000);
        String idText=idOfBranch.getText();
        return idText;
    }

    public String createNewStaff(String staffName, String branchName) throws InterruptedException {
        SU.JSClick(newStaffButton);
        SU.JSClick(branchNameText);
        Thread.sleep(2000);
        SU.enterText(branchNameText,staffName);
       SU.selectDropdown(branchSelectDropdown,branchName);
        SU.JSClick(saveBranch);
        Thread.sleep(3000);
        String idText=idOfStaff.getText();
        return idText;
    }

    public void clickViewBranch() throws InterruptedException {
        Thread.sleep(2000);
        SU.JSClick(viewBranch);
    }

    public void verifyDetails(String action,String entity,String entityName, String code)
    {
        String codeorBranch="";
        if(entity.equalsIgnoreCase("Branch"))
        {
                codeorBranch="code";
        }
        else
            {
                codeorBranch="Branch";
            }
        WebElement viewBranchName=Utilities.driver.findElement(By.xpath("(//input[@value='"+entityName+"'])[last()]"));
        WebElement viewCodeName=Utilities.driver.findElement(By.xpath("(//input[@value='"+code+"'])[last()]"));
        if (viewBranchName.getAttribute("value").equalsIgnoreCase(entityName)&&viewCodeName.getAttribute("value").equalsIgnoreCase(code))
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is able to "+action+" the newly created "+entity+" with "+entity+" name as "+entityName+" and "+codeorBranch+" name as "+code);
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"User is not able to "+action+" the newly created "+entity);
        }
    }

    public void clickBackButton()
    {
        SU.JSClick(backButton);
    }

    public void clickEditButton()
    {
        SU.JSClick(editBranch);
    }

    public void editBranchDetails(String branchName,String code)
    {
        SU.enterText(branchNameText,branchName);
        SU.enterText(codeNameText,code);
        SU.JSClick(saveBranch);
    }

    public void editStaffDetails(String staffName)
    {
        SU.enterText(branchNameText,staffName);
        SU.JSClick(saveBranch);
    }

    static String id="";
    public void clickDeleteButton(String entity)
    {
        if(entity.equalsIgnoreCase("staff"))
        {
            id=idOfStaff.getText();
        }
        else{
            id=idOfBranch.getText();
        }

        SU.JSClick(deleteBranch);
        SU.JSClick(deleteBranchPopup);
    }

    public void verifyDeletedBranch(String entity) throws InterruptedException {
        Thread.sleep(2000);
        boolean flag=false;
        try{
            String xpath="";
            if(entity.equalsIgnoreCase("branch"))
            {
                xpath="branch in branches";
            }
            else{
                xpath="staff in staffs";
            }
        WebElement deletedBranch=Utilities.driver.findElement(By.xpath("//tr[@ng-repeat='"+xpath+"']//a[text()='"+id+"']"));
    }
        catch (Exception ee)
    {
        flag=true;
        StaticInjections.extentTest.log(LogStatus.PASS,entity+" is deleted successfully");
    }

    if(flag==false)
    {
        StaticInjections.extentTest.log(LogStatus.PASS,entity+" is faield to delete");
    }
    }

    public void searchQuery(String value,String entity)
    {
        SU.enterText(searchQueryBox,value);
        WebElement searchButton=Utilities.driver.findElement(By.xpath("//span[text()='Search a "+entity+"']"));
        SU.JSClick(searchButton);
    }
    public void verifySearch(String id,String entity)
    {
        WebElement idEntity=null;
        if(entity.equalsIgnoreCase("branch"))
        {
            idEntity=idOfBranch;
        }
        else{
            idEntity=idOfStaff;
        }

        if (idEntity.getText().equalsIgnoreCase(id))
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is successfully able to query and search the recently created "+entity);
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"User is not able to query and search the recently created "+entity);
        }
    }

    public void clickRegistrationLink()
    {
        SU.JSClick(registerNewUserLink);
    }
    public void verifyRegistrationPage() throws InterruptedException {
        Thread.sleep(2000);
        if (registrationLabel.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"User is successfully navigated to Registration page");
        }
        else
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"User is failed to get navigated to Registration page");
        }
    }

    public void enterNewUserDetails(String login, String email, String password, String confPassword) throws InterruptedException {
        Thread.sleep(2000);
        SU.enterText(loginTextBox,login);
        SU.enterText(emailTextBox,email);
        SU.enterText(passwordTextBoxRegistration,password);
        SU.enterText(confirmPasswordTextBoxRegistration,confPassword);
        SU.JSClick(authenticateButton);
        StaticInjections.extentTest.log(LogStatus.INFO,"User details are: Login - "+login+", email - "+email+", passowrd - "+password);
    }

    public void verifyUserCreation() throws InterruptedException {
        Thread.sleep(2000);
        if (regFailed.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"Registration of new user is failed");
        }
        else if (regSaved.isDisplayed())
        {
            StaticInjections.extentTest.log(LogStatus.PASS,"New user is successfully registered");
        }
    }

    public void verifyStaffDetails(String staffNewN)
    {

    }

}
