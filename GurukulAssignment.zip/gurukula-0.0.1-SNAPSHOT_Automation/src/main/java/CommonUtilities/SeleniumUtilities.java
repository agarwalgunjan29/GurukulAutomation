package CommonUtilities;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.screentaker.ViewportPastingStrategy;

import javax.imageio.ImageIO;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by viagarwal on 6/30/2017.
 */
public class SeleniumUtilities
{

    public void JSClick(WebElement element)
    {
        JavascriptExecutor executor = (JavascriptExecutor)Utilities.driver;
        executor.executeScript("arguments[0].click();", element);
    }

    public Object javaScriptExecute(String script)
    {
        JavascriptExecutor js = (JavascriptExecutor) Utilities.driver;
        return (js.executeScript(script));
    }

    public void enterText(WebElement element, String text)
    {
        element.clear();
        element.sendKeys(text);
    }

    public void selectDropdown(WebElement elem, String value)
    {
        Select dropdown= new Select(elem);
        dropdown.selectByVisibleText(value);
    }

    public void scrollToElement(WebElement el) {
        if (Utilities.driver instanceof JavascriptExecutor) {
            ((JavascriptExecutor) Utilities.driver)
                    .executeScript("arguments[0].scrollIntoView(true);", el);
        }
    }

    public boolean waitUntilElementIsDisappeared(WebElement elem)
    {
        WebDriverWait wait = new WebDriverWait(Utilities.driver, 300);
        boolean val=wait.until(ExpectedConditions.invisibilityOf(elem));
        return val;
    }

    public void waitUntilElementIsClickable(WebElement elem)
    {
        WebDriverWait wait = new WebDriverWait(Utilities.driver, 300);
        wait.until(ExpectedConditions.elementToBeClickable(elem));
    }

    public void waitUntilElementIsVisible(WebElement elem)
    {
        WebDriverWait wait = new WebDriverWait(Utilities.driver, 300);
        wait.until(ExpectedConditions.visibilityOf(elem));
    }

    public void waitForPageLoaded() {
        ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>()
                {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor) Utilities.driver).executeScript("return document.readyState").toString().equals("complete");
                    }
                };
        try {
            Thread.sleep(1000);
            WebDriverWait wait = new WebDriverWait(Utilities.driver, 30);
            wait.until(expectation);
        } catch (Throwable error) {
            Assert.fail("Timeout waiting for Page Load Request to complete.");
        }
    }

    public void waitForElementJquery(String CssSelector) throws InterruptedException {
        Thread.sleep(2000);
        long startTime = System.currentTimeMillis();
        boolean elementPresent = false;
        while(!elementPresent && System.currentTimeMillis()-startTime<60000) {
            JavascriptExecutor js = (JavascriptExecutor) Utilities.driver;
            String elementScript = String.format("return $(\""+CssSelector+"\").is(\":visible\");");
            elementPresent = (boolean) js.executeScript(elementScript);
            if(elementPresent)
            {
                break;
            }
        }

    }

    public List<String> getFireFoxProcessid() throws IOException {
        List<String> firefoxprocessid = new ArrayList<>();
        String line;
        String OS = System.getProperty("os.name").toLowerCase();
        Process p = null;
        if(OS.contains("windows")){
            p = Runtime.getRuntime().exec
                    (System.getenv("windir") +"\\system32\\"+"tasklist.exe");
            BufferedReader input =
                    new BufferedReader(new InputStreamReader(p.getInputStream()));
            while ((line = input.readLine()) != null) {
                if(line.contains("firefox")) {
                   String id = new StringHandling().getFirstOcuurencebetweenStringsusingRegex(line,"firefox.exe","RDP-Tcp").trim();
                    if(!id.contains("match")) {
                        firefoxprocessid.add(new String(id));
                    }
                }
            }
        } else if(OS.contains("linux")){
            p = Runtime.getRuntime().exec("ps -e");
            BufferedReader input =
                    new BufferedReader(new InputStreamReader(p.getInputStream()));
            while ((line = input.readLine()) != null) {
                if(line.contains("firefox")) {
                  //String id = new StringHandling().getFirstOcuurencebetweenStringsusingRegex(line,"firefox.exe","RDP-Tcp").trim();
                    String id =new StringHandling().getFirstofStringusingRegex(line,"?").trim();
                    firefoxprocessid.add(new String(id));


                }
            }
        }

            return firefoxprocessid;
    }




    public String captureScreenShot(String path) throws InterruptedException
    {
        Thread.sleep(1500);
        if(path.toLowerCase().endsWith("html")) {
            path = new File(new File(path).getParent()).getAbsolutePath() + "/screenshot/";
        }else{
            path = new File(path).getAbsolutePath() + "/screenshot/";
        }

        Utilities.createFolder(path);
        String fileName=Utilities.getCurrentTimeStemp()+ ".png";
        String fileWithLocation= (path + fileName);

        try{
            Screenshot screenshot = new AShot().shootingStrategy(new ViewportPastingStrategy(1000)).takeScreenshot(Utilities.driver);
            ImageIO.write(screenshot.getImage(), "PNG", new File(fileWithLocation));
        }catch(Exception e){
            System.out.println("System cannot take the screenshot");
        }
        return " <div align='right' style='float:right'><a href= "+ "./screenshot/"+ fileName + ">Click to view Screenshot</a></div>";


    }

}
