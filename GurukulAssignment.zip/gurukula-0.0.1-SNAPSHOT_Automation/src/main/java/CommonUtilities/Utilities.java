package CommonUtilities;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.screentaker.ViewportPastingStrategy;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Utilities
{
    public static WebDriver driver;

    public String readExcel(String condition, String value)
    {
        String key=null;
         try
         {
             String filePath=getEnvPropertyconfig("excelSheetpath");
             String sheetName="users";
            File file =    new File(filePath);
            FileInputStream inputStream = new FileInputStream(file);
            Workbook workbook = null;
             workbook = new XSSFWorkbook(inputStream);
            Sheet workSheet = workbook.getSheet(sheetName);
            int rowCount = workSheet.getLastRowNum()-workSheet.getFirstRowNum();
            for (int i = 1; i < rowCount+1; i++)
            {
                Row row = workSheet.getRow(i);
                if(row.getCell(0).getStringCellValue().equalsIgnoreCase(condition))
                {
                    if(value.equalsIgnoreCase("UserName"))
                    {
                        key=row.getCell(1).getStringCellValue();
                    }
                    else if(value.equalsIgnoreCase("password"))
                    {
                        key=row.getCell(2).getStringCellValue();
                    }
                    break;
                }
            }
        }catch (Exception exc)
        {
            System.out.println();
        }
        return key;
    }

    public String getEnvPropertyconfig(String key) throws IOException {
        Properties prop = new Properties();
        File file = new File("src/main/resources/Config.properties");
        InputStream input = new FileInputStream(file);
        prop.load(input);
        return prop.getProperty(key);
    }

    //Method for opening browser
    public void openBrowser() throws IOException
    {
        String browserName = getEnvPropertyconfig("broswerName");
        switch (browserName.toLowerCase())
        {
            case "gc":
                System.setProperty("webdriver.chrome.driver", "src\\main\\resources\\BrowserDrivers\\chromedriver.exe");
                driver = new ChromeDriver();
                driver.manage().window().maximize();
                break;
            case "ff":
                System.setProperty("webdriver.gecko.driver", "src\\main\\resources\\BrowserDrivers\\geckodriver.exe");
                driver = new FirefoxDriver();
                driver.manage().window().maximize();
                break;
            case "ie":
                System.setProperty("webdriver.ie.driver", "src\\main\\resources\\BrowserDrivers\\IEDriverServer.exe");
                driver = new InternetExplorerDriver();
                driver.manage().window().maximize();
                break;
        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    public void navigateToURL(String url) throws IOException
    {
        driver.get(url);
    }

    public void scrollToElement(WebElement el)
    {
        if (driver instanceof JavascriptExecutor)
        {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el);
        }
    }

    public void waitForPageLoaded() {
        ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>()
        {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            }
        };
        try {
            Thread.sleep(1000);
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(expectation);
        } catch (Throwable error) {
            Assert.fail("Timeout waiting for Page Load Request to complete.");
        }
    }

    public String captureScreenShot(String path) throws InterruptedException
    {
        Thread.sleep(1500);
        if(path.toLowerCase().endsWith("html")) {
            path = new File(new File(path).getParent()).getAbsolutePath() + "/screenshot/";
        }else{
            path = new File(path).getAbsolutePath() + "/screenshot/";
        }

        File fileLocation= new File(path);
        if(!fileLocation.exists())
            new File(path).mkdir();

        String fileName=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(System.currentTimeMillis())).replace(".", "_")+ ".png";
        String fileWithLocation= (path + fileName);

        try{
            Screenshot screenshot = new AShot().shootingStrategy(new ViewportPastingStrategy(1000)).takeScreenshot(driver);
            ImageIO.write(screenshot.getImage(), "PNG", new File(fileWithLocation));
        }catch(Exception e){
            System.out.println("System cannot take the screenshot");
        }
        return " <div align='right' style='float:right'><a href= "+ "./screenshot/"+ fileName + ">Click to view Screenshot</a></div>";


    }


    public String getDate(int daycount)
    {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        if(daycount==0)
        {
            String strDate = formatter.format(date);
            return strDate;
        }
        else
        {
            Calendar c = Calendar.getInstance();

            c.add(Calendar.DATE,daycount);
            String strDate = formatter.format(c.getTime());
            return strDate;
        }
    }

    public static void createFolder(String directory)
    {
        File fileLocation= new File(directory);
        if(!fileLocation.exists())
            new File(directory).mkdir();
    }

    public static String getCurrentTimeStemp()
    {
        return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(System.currentTimeMillis())).replace(".", "_");
    }


}
