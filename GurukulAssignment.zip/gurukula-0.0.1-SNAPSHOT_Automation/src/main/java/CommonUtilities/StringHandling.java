package CommonUtilities;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;

import java.io.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by amuthusa on 03/03/2017.
 */
public class StringHandling {

    public String generateRandomString()
    {
        int length = 6;
        boolean useLetters = true;
        boolean useNumbers = false;
        String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
        return generatedString.toLowerCase();
    }


    public Boolean isSubstringPresent(String mainString, String subString) {
        if (mainString.toLowerCase().contains(subString.toLowerCase())) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    public Boolean isSubstringnotPresent(String mainString, String subString) {
        if (mainString.toLowerCase().contains(subString.toLowerCase())) {
            return Boolean.FALSE;
        } else {
            return Boolean.TRUE;
        }
    }

    public String getFirstOcuurencebetweenStringsusingRegex(String mainString, String pattern1, String pattern2)
    {
        String returnString =null;
        Pattern p = Pattern.compile(Pattern.quote(pattern1) + "(.*?)" + Pattern.quote(pattern2));
        Matcher m = p.matcher(mainString);
        while (m.find()) {

            returnString = m.group(1);

        }

        if(returnString==null)
        {
            returnString = "No match";

        }

        return  returnString;

    }


    public String getFirstofStringusingRegex(String mainString, String pattern1)
    {
        String returnString =null;
        Pattern p = Pattern.compile( "(.*?)" + Pattern.quote(pattern1));
        Matcher m = p.matcher(mainString);
        while (m.find()) {

            returnString = m.group(1);

        }


        return  returnString;

    }
//    public void enCryptString(String stringtobeencrypted)
//    {
//        byte[] message = "hello world".getBytes(StandardCharsets.UTF_8);
//        String encoded = Base64.getEncoder().encodeToString(message);
//        byte[] decoded = Base64.getDecoder().decode(encoded);
//        String s = new String(decoded);
//
//    }

    public int getOccurrencesofSubstring(String Mainstring, String Substring) {
        int lastIndex = 0;
        int occurrence = 0;
        while (lastIndex != -1) {
            lastIndex = Mainstring.indexOf(Substring, lastIndex);
            if (lastIndex != -1) {
                occurrence++;
                lastIndex += Substring.length();
            }
        }
        return occurrence;
    }

    public String formatErrorCode(String errorCode) {
        int errorcodelength = errorCode.length();

        String formattedErrorCode = errorCode.substring(0, errorcodelength) + "-" + errorCode.substring(errorcodelength);

        return formattedErrorCode;
    }

    public List<String> splitMIloadparameter(String stringtosplit) {
        String[] parameterlist;
        parameterlist = stringtosplit.split("/");
        List<String> parameter = new ArrayList<>();
        for (String item : parameterlist) {
            parameter.add(item);
        }
        return parameter;
    }

    public int nthIndexOf(String mainString, final String token,
                          int index) {
        int j = 0;

        for (int i = 0; i < index; i++) {
            j = mainString.indexOf(token, j + 1);
            if (j == -1) break;
        }

        return j;
    }

    public String getCurrentDatetime(){
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        Date date = new Date();
        String act = dateFormat.format(date);
        return dateFormat.format(date);
    }


    public String getTimefromDatetime(String dateTime) throws ParseException {
        DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d = f.parse(dateTime);
        DateFormat time = new SimpleDateFormat("hh:mm:ss");
        return time.format(d);

    }

    public String getdatefromDatetime(String dateTime) throws ParseException {
        DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d = f.parse(dateTime);
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        return date.format(d);
    }

    public String increaseTimeby(String time, int increasebyminute) throws ParseException {
        String myTime = time;
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
        Date d = df.parse(myTime);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        cal.add(Calendar.MINUTE, increasebyminute);
        String newTime = df.format(cal.getTime());
        return newTime;
    }


    public String increaseDateby(String datetoConvert, int increasebydays) throws ParseException {

        String mydate = datetoConvert;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date d = df.parse(mydate);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        cal.add(Calendar.DATE, increasebydays);
        String newdate = df.format(cal.getTime());
        return newdate;

    }

    public String Jahiatimezone(String datetoConvert, int increasebydays) throws ParseException {

        String mydate = datetoConvert;
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date d = df.parse(mydate);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        cal.add(Calendar.DATE, increasebydays);
        String newdate = df.format(cal.getTime());
        return newdate;

    }

//    public String decreaseDateby(String datetoConvert, int decreasebydays) throws ParseException {
//
//        String mydate = datetoConvert;
//        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
//        Date d = df.parse(mydate);
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(d);
//        cal.add(Calendar.DATE, -decreasebydays);
//        String newdate = df.format(cal.getTime());
//        return newdate;
//
//    }


//    public Date yesterday(DateFormat ExpectedFormat) {
//        final Calendar cal = Calendar.getInstance();
//        cal.add(Calendar.DATE, -1);
//        DateFormat dateFormat = new SimpleDateFormat(ExpectedFormat);
//        return cal.getTime();
//    }

    public String dateFormatConverter(String dateToConvert, String inputFormat, String outputFormat) throws ParseException {
        return new SimpleDateFormat(outputFormat).format(new SimpleDateFormat(inputFormat).parse(dateToConvert));
    }

    public void writeCSVfileresult(String csvpath, String scenarioName, String status, String StepName, String description) throws IOException {
        File file = new File(csvpath);
        PrintWriter pw = new PrintWriter(new FileOutputStream(new File(csvpath), true));
        pw.write(scenarioName + "," + status + "," + StepName + "," + description);
        pw.println();
        pw.flush();
        pw.close();
    }

    public void CsvResultforFileSequencing(String csvpath, String SubmittingEntity,String FileIdentifier, String expectedResult, String OpsConsolestatus, String userportalStatus, String opsConsoleConError, String userportalConError, String testStatus) throws IOException {
        PrintWriter pw = new PrintWriter(new FileOutputStream(new File(csvpath), true));
        pw.write(SubmittingEntity + "," + FileIdentifier + "," + expectedResult + "," + OpsConsolestatus + "," + userportalStatus + "," + opsConsoleConError + "," + userportalConError+","+testStatus);
        pw.println();
        pw.flush();
        pw.close();
    }

    public void Csvrecordreport(String outputcsvpath, String submittingEntity, String fileIdentifier,String  expectedResult, String OpsconsoleStatus,String userportalStatus,String opsconsoleacceptedCount,String opsconsolerejectedCount,String  opsconsolewarningCount,String  opsconsolependingCount,String  opsconsolereceivedCount,String  userportalacceptedCount,String  userportalrejectedCount,String  userportalwarningCount,String  userportalpendingCount,String  userportalreceivedCount,String csvacceptedCount,String csvrejectedCount,String csvpendingCount,String csvwarningCount,String csvreceivedCount,String opsConsolefeedbackCount,String useprotalfeedbackCount,String teststatus) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(new FileOutputStream(new File(outputcsvpath), true));
        pw.write(submittingEntity + "," + fileIdentifier + "," + expectedResult + "," + OpsconsoleStatus + "," + userportalStatus + "," + opsconsoleacceptedCount + "," + opsconsolerejectedCount+","+opsconsolewarningCount+","+opsconsolependingCount+","+opsconsolereceivedCount+","+userportalacceptedCount+","+userportalrejectedCount+","+userportalwarningCount+","+userportalpendingCount+","+userportalreceivedCount+","+csvacceptedCount+","+csvrejectedCount+","+csvpendingCount+","+csvwarningCount+","+csvreceivedCount+","+opsConsolefeedbackCount+","+useprotalfeedbackCount+","+teststatus);
        pw.println();
        pw.flush();
        pw.close();

    }

    public String returnwithDQ(String input) {
        if (input != null) {

            if (input.contains("\"")) {

                input = input.replace("\"", "\\\"");
            }


            if (input.contains(",")) {
                if (input.equals("FALSE")) {
                    input = "false";
                }

                return "\"" + input + "\"".trim();

            } else {

                if (input.equals("null")) {
                    input = "";

                }

                if (input.toLowerCase().equals("false")) {

                    input = "false".toLowerCase().trim();
                }

                return input.trim();
            }
        } else {
            return "null".trim();
        }
    }

    public String formattedRedshiftString(String redshiftString) throws ParseException {
        String formmattedredshiftString = null;
        boolean dateString = false;
// Check if it is not character
        if (!redshiftString.matches("[a-zA-Z0-9]+")) {
            // check if it is date
            Matcher m = Pattern.compile("[0-9]{1,2}-[a-zA-Z]{3}-[0-9]{4}", Pattern.CASE_INSENSITIVE).matcher(redshiftString);
            while (m.find()) {
                {
                    dateString = true;
                    DateFormat shortFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                    DateFormat mediumFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
                    String shortDate = shortFormat.format(mediumFormat.parse(m.group()));
                    System.out.println(shortDate);
                    formmattedredshiftString = redshiftString.replace(m.group(), shortDate);

                }
            }
            if (!dateString) {
                if(redshiftString.matches("[0-9.]+"))
                {
                    formmattedredshiftString = redshiftString.replaceFirst("\\.0*$|(\\.\\d*?)0+$", "$1");

                }else
                {

                    formmattedredshiftString = redshiftString;
                }

                //formmattedredshiftString = redshiftString.replaceFirst("\\.0*$|(\\.\\d*?)0+$", "$1");

            }

        } else {
            formmattedredshiftString = redshiftString;
        }

        if(formmattedredshiftString.isEmpty())
        {
            formmattedredshiftString = "null";

        }

        if(formmattedredshiftString==null)
        {
            formmattedredshiftString = "null";

        }

        return formmattedredshiftString;

    }

    public int resultSetCount(int maxCount)
    {
        int didvider = 144814;
        double quotient = maxCount/didvider;
        if(quotient>1)
        {
           return  (int)Math.ceil(maxCount / 144814.0);
            //return Math.toIntExact(Math.round(quotient));
        }else
        {
            return 1;

        }

    }


    public String addDays(String sourceDate, int days) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(sdf.parse(sourceDate));
        c.add(Calendar.DATE, days);
        String modifiedDate;
        modifiedDate = sdf.format(c.getTime());
        return modifiedDate;
        }

        public boolean checkNullEmpty(String value)
        {
            if(value!=null)
            {
                if(!value.isEmpty())
                {
                    return true;
                }
                else{return false;}
            }
            else {return false;}
        }
    //Used to get filtered hashmap based on partkey
    public HashMap<String, String> getFilteredHashMap(HashMap<String,String> myMap, String partKey){
        HashMap<String, String> newMap= new HashMap<String, String>();

        String tempStr = "";

        for(Map.Entry m:myMap.entrySet()){
            tempStr = (String) m.getKey();
            if(tempStr.contains(partKey)){
                newMap.put(m.getKey().toString(), m.getValue().toString());

            }
        }
        return newMap;
    }
}

