package CommonUtilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class StaticInjections
{
    public static String workingFolder=null;
    public static ExtentTest extentTest=null;
    public static ExtentReports extentReports=null;
    public static String screenahotPath=null;
}
