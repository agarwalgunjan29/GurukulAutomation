package Cukes;

import CommonUtilities.StaticInjections;
import CommonUtilities.StringHandling;
import CommonUtilities.Utilities;
import PageObjects.WebsitePageFactory;
import com.relevantcodes.extentreports.LogStatus;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WebSiteValidation
{
    @Given("^User is on the welcome page")
    public void userIsOnTheHomepageOfLinkedin()
    {
        Utilities util=new Utilities();
        try
        {
            util.openBrowser();
            util.navigateToURL(util.getEnvPropertyconfig("URL"));
            new WebsitePageFactory(Utilities.driver).verifyWelcomePage();
        }
        catch (Exception exc)
        {
            StaticInjections.extentTest.log(LogStatus.FAIL,"Fail to launch the website");
            System.out.println(exc);
        }
    }

    @When("^User enter userName as '(.*)' and Password as '(.*)' in the text field and click on authenticate button$")
    public void userEnterUserNameAsAdminAndPasswordAsAdminInTheTextFieldAndClickOnAuthenticateButton(String userName,String password) throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).enterUserName(userName);
        new WebsitePageFactory(Utilities.driver).enterPassword(password);
        new WebsitePageFactory(Utilities.driver).clickSignInButton();

    }

    @Then("^User should be able to logged in to the website$")
    public void userShouldBeAbleToLoggedInToTheWebsite()
    {
        new WebsitePageFactory(Utilities.driver).verifyHomePage();
    }


    @And("^user click on login link to login to website$")
    public void userClickOnLoginLinkToLoginToWebsite()
    {
        new WebsitePageFactory(Utilities.driver).clickLoginButton();
    }

    @When("^User clicked on the logout button$")
    public void userClickedOnTheLogoutButton() throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).clickAccountButton();
        new WebsitePageFactory(Utilities.driver).clickLogoutButton();
    }

    @Then("^User should be navigated back to welcome page$")
    public void userShouldBeNavigatedBackToWelcomePage()
    {
        new WebsitePageFactory(Utilities.driver).verifyWelcomePage();
    }

    @Then("^User should displayed the authentication error message$")
    public void userShouldDisplayedTheAuthenticationErrorMessage()
    {
        new WebsitePageFactory(Utilities.driver).verifyAuthentication();
    }

    @When("^User clicked on the Settings button$")
    public void userClickedOnTheSettingsButton() throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).clickOnSettings();
    }

    @And("^User update the details of logged-in user$")
    public void userUpdateTheDetailsOfLoggedInUser()  {
        new WebsitePageFactory(Utilities.driver).updateDetails();
    }

    @Then("^User should be able to update the user details successfully$")
    public void userShouldBeAbleToUpdateTheUserDetailsSuccessfully() {
        new WebsitePageFactory(Utilities.driver).verifySettingsUpdated();
    }

    @When("^User click on the branch button from Enitites$")
    public void userClickOnTheBranchButtonFromEnitites() throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).clickOnEntities();
        new WebsitePageFactory(Utilities.driver).clickOnBranch();
        Thread.sleep(2000);
    }

    @Then("^User should be displayed an option to Create a new '(.*)'")
    public void userSholdBeDisplayedAnOptionToCreateANewBranch(String entity) throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).verifyCreateBranchButton(entity);
        Thread.sleep(2000);
    }


    String queryId="";
    @When("^User click on Create new branch button and enter branch name as '(.*)' and code as '(.*)' and click on Save button$")
    public void userClickOnCreateNewBranchButtonAndEnterBranchNameAsBranchNameAndCodeAsCODEAndClickOnSaveButton(String branchName,String code) throws InterruptedException {
        queryId=new WebsitePageFactory(Utilities.driver).createNewBranch(branchName,code);
        Thread.sleep(2000);
    }

    @Then("^User should be able to '(.*)' branch with branch name as '(.*)' and code as '(.*)'$")
    public void userShouldBeAbleToViewTheNewlyCreatedBranchWithBranchNameAsBranchNameAndCodeAsCODE(String action,String branchName,String code) throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).clickViewBranch();
        Thread.sleep(3000);
        new WebsitePageFactory(Utilities.driver).verifyDetails(action,"branch",branchName,code);
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).clickBackButton();
    }

    @When("^User edit the branch with branch name as '(.*)' and code as '(.*)'$")
    public void userEditTheBranchWithBranchNameAsBranchNewNameAndCodeAsNEWCODE(String branchName,String code) throws InterruptedException {
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).clickEditButton();
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).editBranchDetails(branchName,code);
    }

    @When("^User click on the Delete button to delete the '(.*)'")
    public void userClickOnTheDeleteButtonToDeleteTheBranch(String entity) throws InterruptedException {
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).clickDeleteButton(entity);
    }

    @Then("^User should not be able to view the deleted '(.*)' anymore$")
    public void userShouldNotBeAbleToViewTheDeletedBranchAnymore(String entity) throws InterruptedException {
        try{
        new WebsitePageFactory(Utilities.driver).verifyDeletedBranch(entity);
        }
        catch (Exception ee)
        {
            System.out.println(ee);
        }
    }

    @When("^User click on the Register a new account link$")
    public void userClickOnTheRegisterANewAccountLink()
    {
        new WebsitePageFactory(Utilities.driver).clickRegistrationLink();
    }

    @Then("^User should be navigated to registration page$")
    public void userShouldBeNavigatedToRegistrationPage() throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).verifyRegistrationPage();
    }

    @When("^User enters login name, email, NewPassword as '(.*)' and confirmPassword as '(.*)' and click on the Register button$")
    public void userEntersLoginAsEmailAsNewPasswordAsConfirmPasswordAsAndClickOnTheRegisterButton(String password, String confirmPassword) throws InterruptedException {
        String random=new StringHandling().generateRandomString();
        new WebsitePageFactory(Utilities.driver).enterNewUserDetails(random,random+"@"+random,password,confirmPassword);
    }

    @Then("^User should be successfully created$")
    public void userShouldBeSuccessfullyCreated() throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).verifyUserCreation();
    }

    @When("^User click on the staff button from Enitites$")
    public void userClickOnTheStaffButtonFromEnitites()  {
        new WebsitePageFactory(Utilities.driver).clickOnEntities();
        new WebsitePageFactory(Utilities.driver).clickOnStaff();
    }

    @Then("^User should be displayed an option to Create a new Staff$")
    public void userShouldBeDisplayedAnOptionToCreateANewStaff() throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).verifyCreateStaffButton();
        Thread.sleep(2000);
    }

    @When("^User click on Create new Staff button and enter staff name as '(.*)' and select branch as '(.*)' and click on Save button$")
    public void userClickOnCreateNewStaffButtonAndEnterStaffNameAsStaffNameAndSelectBranchAsBranchNameAndClickOnSaveButton(String staffName,String branchName) throws InterruptedException {
        queryId=new WebsitePageFactory(Utilities.driver).createNewStaff(staffName,branchName);
        Thread.sleep(2000);
    }

    @Then("^User should be able to query the created '(.*)'")
    public void userShouldBeAbleToQueryTheCreatedStaff(String entity) throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).searchQuery(queryId,entity);
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).verifySearch(queryId,entity);
    }

    @Then("^User should be able to '(.*)' staff with staff name as '(.*)' and branch as '(.*)'$")
    public void userShouldBeAbleToViewStaffWithStaffNameAsStaffNameAndBranchAsBranchName(String action,String staffName,String branchName) throws InterruptedException {
        new WebsitePageFactory(Utilities.driver).clickViewBranch();
        Thread.sleep(3000);
        new WebsitePageFactory(Utilities.driver).verifyDetails(action,"staff",staffName,branchName);
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).clickBackButton();
    }

    @When("^User edit the staff with staff name as '(.*)'$")
    public void userEditTheBranchWithStaffNameAsStaffNameAndBranchAsBranchName(String staffName) throws InterruptedException {
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).clickEditButton();
        Thread.sleep(2000);
        new WebsitePageFactory(Utilities.driver).editStaffDetails(staffName);
    }
}
