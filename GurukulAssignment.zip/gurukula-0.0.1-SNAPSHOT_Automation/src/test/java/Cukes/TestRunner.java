package Cukes;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by amuthusa.adm on 3/15/2017.
 */

@CucumberOptions(features={"src/test/Resources/Features/"},glue={"gurukula-0.0.1-SNAPSHOT_Automation.Cukes"},plugin={"pretty","html:target/report"})
@RunWith(Cucumber.class)

public class TestRunner
{

}
