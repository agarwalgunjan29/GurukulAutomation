package Cukes;

import CommonUtilities.StaticInjections;
import CommonUtilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.junit.Assert;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static CommonUtilities.StaticInjections.extentReports;
import static CommonUtilities.StaticInjections.screenahotPath;
import static CommonUtilities.StaticInjections.workingFolder;

public class WebSiteValidationHooks
{
    static int counter=0;
    static String htmlReportPath=null;
    @Before("@WebsiteValidation")
    public void websiteBeforeScenario(Scenario scenario) throws IOException {

        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String time = dateFormat.format(now);
        workingFolder="src/test/Resources/Results//";
        if(counter==0)
        {
            counter=1;
            htmlReportPath= workingFolder+time+"_WebSiteValidations.html";
        }
        extentReports=new ExtentReports(htmlReportPath, false);
        String browser=new Utilities().getEnvPropertyconfig("broswerName").toLowerCase();
        switch (browser)
        {
            case "ff":
                StaticInjections.extentReports.addSystemInfo("Browser Name","Firefox");
                break;
            case "gc":
                StaticInjections.extentReports.addSystemInfo("Browser Name","Google Chrome");
                break;
            case "ie":
                StaticInjections.extentReports.addSystemInfo("Browser Name","Internet Explorer");
                break;
        }
        StaticInjections.extentTest = StaticInjections.extentReports.startTest(scenario.getName()).assignCategory("Website Validation");
        File workingDirectory = new File(workingFolder + "//");
        if (!workingDirectory.exists()) {
            workingDirectory.mkdirs();
        }
    }

    @After("@WebsiteValidation")
    public void websiteAfterScenario(Scenario scenario) throws IOException
    {
        extentReports.endTest(StaticInjections.extentTest);
        extentReports.flush();
//        Utilities.driver.quit();
    }

}
